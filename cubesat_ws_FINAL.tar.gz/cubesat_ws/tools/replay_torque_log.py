#!/usr/bin/env python3

import argparse
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class TorqueLogReplay(Node):
    def __init__(self, log_file, dt, loop):
        super().__init__("torque_log_replay")

        self.pub = self.create_publisher(
            Float32,
            "/reaction_wheel/net_torque",
            10
        )

        self.log_file = log_file
        self.dt = dt
        self.loop = loop

        # Senin logdan aldigimiz neutral/bias torque
        self.tau_neutral = -0.0045

        # Gazebo icin olcekleme
        self.scale = 30.0

        # Kucuk sapmalari sifirla
        self.deadband = 0.0005

        # Asiri tork gitmesin
        self.max_torque = 0.08

        self.samples = self.load_log(log_file)
        self.i = 0

        self.get_logger().info(f"Log yuklendi: {log_file}")
        self.get_logger().info(f"Toplam gecerli satir: {len(self.samples)}")
        self.get_logger().info(f"tau_neutral = {self.tau_neutral:+.4f} Nm")
        self.get_logger().info(f"scale = {self.scale}")
        self.get_logger().info("PWM 1000-1000 ise torque = 0")
        self.get_logger().info("Log replay basliyor...")

        self.timer = self.create_timer(self.dt, self.step)

    def load_log(self, path):
        samples = []

        with open(path, "r") as f:
            for line in f:
                line = line.strip()

                if not line:
                    continue

                if line.startswith("["):
                    continue

                parts = line.split()

                if len(parts) != 5:
                    continue

                try:
                    f1 = float(parts[0])
                    f2 = float(parts[1])
                    tau_raw = float(parts[2])
                    pwm1 = int(float(parts[3]))
                    pwm2 = int(float(parts[4]))
                except ValueError:
                    continue

                samples.append((f1, f2, tau_raw, pwm1, pwm2))

        return samples

    def clamp(self, x, lo, hi):
        return max(lo, min(hi, x))

    def step(self):
        if self.i >= len(self.samples):
            if self.loop:
                self.i = 0
                self.get_logger().info("Log basa sardirildi.")
            else:
                msg = Float32()
                msg.data = 0.0
                self.pub.publish(msg)
                self.get_logger().info("Log bitti. Torque 0'a cekildi.")
                self.timer.cancel()
                return

        f1, f2, tau_raw, pwm1, pwm2 = self.samples[self.i]
        self.i += 1

        if pwm1 <= 1005 and pwm2 <= 1005:
            tau_clean = 0.0
            tau_gazebo = 0.0
        else:
            tau_clean = tau_raw - self.tau_neutral

            if abs(tau_clean) < self.deadband:
                tau_clean = 0.0

            tau_gazebo = tau_clean * self.scale
            tau_gazebo = self.clamp(
                tau_gazebo,
                -self.max_torque,
                self.max_torque
            )

        msg = Float32()
        msg.data = float(tau_gazebo)
        self.pub.publish(msg)

        self.get_logger().info(
            f"i={self.i:03d} raw={tau_raw:+.4f} | "
            f"clean={tau_clean:+.4f} | gazebo={tau_gazebo:+.4f} | "
            f"PWM={pwm1},{pwm2}"
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", default="/home/memin/cubesat_ws/tools/torque_log.txt")
    parser.add_argument("--dt", type=float, default=0.30)
    parser.add_argument("--loop", action="store_true")
    args = parser.parse_args()

    rclpy.init()
    node = TorqueLogReplay(args.file, args.dt, args.loop)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
