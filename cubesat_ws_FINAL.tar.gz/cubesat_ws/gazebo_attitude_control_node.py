#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String


class GazeboAttitudeControlNode(Node):
    def __init__(self):
        super().__init__('gazebo_attitude_control_node')

        # CAD-based yaw inertia from Autodesk Inventor
        self.Izz = 0.002718905  # kg*m^2

        # Safety limits
        self.torque_limit = 0.02      # N*m
        self.rate_limit = 0.04        # N*m/s
        self.filter_alpha = 0.25
        self.damping = 0.96

        # PD attitude control gains
        self.Kp = 0.012
        self.Kd = 0.010

        self.world = 'space'
        self.model = 'cubesat'
        self.z_height = 1.0

        self.mode = 'manual_torque'
        self.target_yaw = 0.0

        self.manual_torque = 0.0
        self.torque_filtered = 0.0
        self.torque_out = 0.0

        self.yaw = 0.0
        self.omega = 0.0
        self.last_time = self.get_clock().now()

        self.create_subscription(
            Float32,
            '/reaction_wheel/net_torque',
            self.manual_torque_callback,
            10
        )

        self.create_subscription(
            Float32,
            '/cubesat/target_yaw_deg',
            self.target_yaw_callback,
            10
        )

        self.yaw_pub = self.create_publisher(Float32, '/cubesat/current_yaw_deg', 10)
        self.mode_pub = self.create_publisher(String, '/cubesat/control_mode', 10)

        self.timer = self.create_timer(0.05, self.update_pose)

        self.get_logger().info('Listening: /reaction_wheel/net_torque')
        self.get_logger().info('Listening: /cubesat/target_yaw_deg')
        self.get_logger().info('Publishing: /cubesat/current_yaw_deg')
        self.get_logger().info('Gazebo attitude control node started.')

    def manual_torque_callback(self, msg):
        self.manual_torque = float(msg.data)
        self.mode = 'manual_torque'

    def target_yaw_callback(self, msg):
        self.target_yaw = math.radians(float(msg.data))
        self.mode = 'angle_control'
        self.get_logger().info(f'Target yaw set to {float(msg.data):.2f} deg')

    def clamp(self, value, min_value, max_value):
        return max(min(value, max_value), min_value)

    def wrap_pi(self, angle):
        return (angle + math.pi) % (2.0 * math.pi) - math.pi

    def update_pose(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        if dt <= 0.0 or dt > 0.5:
            dt = 0.05

        if self.mode == 'angle_control':
            error = self.wrap_pi(self.target_yaw - self.yaw)
            torque_raw = self.Kp * error - self.Kd * self.omega
        else:
            torque_raw = self.manual_torque

        # Low-pass filter
        self.torque_filtered = (
            self.filter_alpha * torque_raw
            + (1.0 - self.filter_alpha) * self.torque_filtered
        )

        # Saturation
        torque_sat = self.clamp(
            self.torque_filtered,
            -self.torque_limit,
            self.torque_limit
        )

        # Rate limit
        max_step = self.rate_limit * dt
        delta = self.clamp(torque_sat - self.torque_out, -max_step, max_step)
        self.torque_out += delta

        # Yaw dynamics: Izz * yaw_ddot = torque
        yaw_acc = self.torque_out / self.Izz
        self.omega += yaw_acc * dt
        self.omega *= self.damping
        self.yaw += self.omega * dt
        self.yaw = self.wrap_pi(self.yaw)

        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{self.model}" '
            f'position {{ x: 0 y: 0 z: {self.z_height} }} '
            f'orientation {{ x: 0 y: 0 z: {qz} w: {qw} }}'
        )

        cmd = [
            'gz', 'service',
            '-s', f'/world/{self.world}/set_pose',
            '--reqtype', 'gz.msgs.Pose',
            '--reptype', 'gz.msgs.Boolean',
            '--timeout', '100',
            '--req', req
        ]

        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.2
            )
        except Exception:
            pass

        yaw_msg = Float32()
        yaw_msg.data = math.degrees(self.yaw)
        self.yaw_pub.publish(yaw_msg)

        mode_msg = String()
        mode_msg.data = self.mode
        self.mode_pub.publish(mode_msg)


def main():
    rclpy.init()
    node = GazeboAttitudeControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
