import time
from collections import deque

import serial
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, Int32, String


SERIAL_PORT = "/dev/ttyUSB0"
BAUD_RATE = 115200

# Gazebo hareketi azsa artır, çok hızlıysa azalt
TORQUE_GAIN = 1.0

# Bundan küçük değerleri Gazebo'ya 0 gönder
NET_TORQUE_DEADBAND = 0.0012  # Nm

# Low-pass filtre
ALPHA = 0.20

# Motor disabled iken değer stabil kalırsa onu yeni sıfır kabul et
AUTO_ZERO_WHEN_DISABLED = True
AUTO_ZERO_WINDOW = 80            # yaklaşık 1.5-2 saniye
AUTO_ZERO_STABLE_RANGE = 0.00035 # Nm
AUTO_ZERO_RATE = 0.30


class ESP32LoadcellBridge(Node):
    def __init__(self):
        super().__init__("esp32_loadcell_bridge")

        self.zero_offset = 0.0
        self.filtered_net_torque = 0.0

        self.raw_history = deque(maxlen=AUTO_ZERO_WINDOW)

        self.zero_active = False
        self.zero_wait_until = 0.0
        self.zero_end_time = 0.0
        self.zero_samples = []

        self.last_log_time = time.monotonic()

        self.net_torque_pub = self.create_publisher(
            Float32,
            "/reaction_wheel/net_torque",
            10
        )

        self.raw_net_torque_pub = self.create_publisher(
            Float32,
            "/reaction_wheel/raw_net_torque",
            10
        )

        self.corrected_net_torque_pub = self.create_publisher(
            Float32,
            "/reaction_wheel/corrected_net_torque",
            10
        )

        self.zero_offset_pub = self.create_publisher(
            Float32,
            "/reaction_wheel/zero_offset",
            10
        )

        self.force1_pub = self.create_publisher(Float32, "/loadcell/force1_N", 10)
        self.force2_pub = self.create_publisher(Float32, "/loadcell/force2_N", 10)

        self.torque1_pub = self.create_publisher(Float32, "/loadcell/torque1_Nm", 10)
        self.torque2_pub = self.create_publisher(Float32, "/loadcell/torque2_Nm", 10)

        self.pwm1_pub = self.create_publisher(Int32, "/esc/pwm1_us", 10)
        self.pwm2_pub = self.create_publisher(Int32, "/esc/pwm2_us", 10)
        self.enabled_pub = self.create_publisher(Int32, "/esp32/enabled", 10)

        self.cmd_sub = self.create_subscription(
            String,
            "/esp32/cmd",
            self.cmd_callback,
            10
        )

        self.ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.05)

        self.timer = self.create_timer(0.01, self.read_serial)

        self.get_logger().info(f"ESP32 bridge started on {SERIAL_PORT}")
        self.get_logger().info("Zero-offset + deadband + auto-zero bridge active.")
        self.get_logger().info("Commands:")
        self.get_logger().info("  e = enable motors")
        self.get_logger().info("  s = stop motors")
        self.get_logger().info("  t = Arduino tare + software zero")
        self.get_logger().info("  z = only software zero")

    def start_zero(self, reason="software zero", wait_s=0.3, collect_s=1.5):
        now = time.monotonic()
        self.zero_active = True
        self.zero_wait_until = now + wait_s
        self.zero_end_time = now + wait_s + collect_s
        self.zero_samples = []
        self.filtered_net_torque = 0.0
        self.get_logger().info(f"Zero started: {reason}")

    def cmd_callback(self, msg):
        cmd = msg.data.strip()

        if cmd in ["e", "E"]:
            self.ser.write(b"e")
            self.filtered_net_torque = 0.0
            self.get_logger().info("Sent command to ESP32: e")

        elif cmd in ["s", "S"]:
            self.ser.write(b"s")
            self.filtered_net_torque = 0.0
            self.start_zero("stop command auto-zero", wait_s=0.5, collect_s=1.0)
            self.get_logger().info("Sent command to ESP32: s")

        elif cmd in ["t", "T"]:
            self.ser.write(b"t")
            self.filtered_net_torque = 0.0

            # Arduino tare yaklaşık birkaç saniye sürdüğü için önce bekliyoruz,
            # sonra ROS tarafında da software zero alıyoruz.
            self.start_zero("Arduino tare + ROS software zero", wait_s=3.8, collect_s=1.5)
            self.get_logger().info("Sent command to ESP32: t")

        elif cmd in ["z", "Z"]:
            # ESP32'ye göndermiyoruz. Sadece ROS tarafında mevcut değeri sıfır kabul ediyoruz.
            self.start_zero("ROS software zero only", wait_s=0.3, collect_s=1.5)

        else:
            self.get_logger().warn(f"Unknown command ignored: {cmd}")

    def pub_float(self, pub, value):
        msg = Float32()
        msg.data = float(value)
        pub.publish(msg)

    def pub_int(self, pub, value):
        msg = Int32()
        msg.data = int(value)
        pub.publish(msg)

    def publish_all(self, f1, f2, torque1, torque2, raw_net_torque,
                    corrected_net_torque, net_torque, pwm1, pwm2, enabled):
        self.pub_float(self.force1_pub, f1)
        self.pub_float(self.force2_pub, f2)

        self.pub_float(self.torque1_pub, torque1)
        self.pub_float(self.torque2_pub, torque2)

        self.pub_float(self.raw_net_torque_pub, raw_net_torque)
        self.pub_float(self.corrected_net_torque_pub, corrected_net_torque)
        self.pub_float(self.net_torque_pub, net_torque)
        self.pub_float(self.zero_offset_pub, self.zero_offset)

        self.pub_int(self.pwm1_pub, pwm1)
        self.pub_int(self.pwm2_pub, pwm2)
        self.pub_int(self.enabled_pub, enabled)

    def process_torque(self, raw_net_torque, enabled):
        now = time.monotonic()

        self.raw_history.append(raw_net_torque)

        # Software zero aktifse belli süre örnek topla ve ortalamasını offset yap
        if self.zero_active:
            if now < self.zero_wait_until:
                corrected = 0.0
                net = 0.0
                return corrected, net

            if now <= self.zero_end_time:
                self.zero_samples.append(raw_net_torque)
                corrected = 0.0
                net = 0.0
                return corrected, net

            if len(self.zero_samples) > 0:
                self.zero_offset = sum(self.zero_samples) / len(self.zero_samples)
                self.get_logger().info(
                    f"Zero completed. New zero_offset = {self.zero_offset:.6f} Nm"
                )

            self.zero_active = False
            self.zero_samples = []
            self.filtered_net_torque = 0.0

            corrected = 0.0
            net = 0.0
            return corrected, net

        # Motor disabled iken residual/stabil yük kalırsa yavaşça sıfıra çek
        if AUTO_ZERO_WHEN_DISABLED and enabled == 0 and len(self.raw_history) == AUTO_ZERO_WINDOW:
            stable_range = max(self.raw_history) - min(self.raw_history)

            if stable_range < AUTO_ZERO_STABLE_RANGE:
                avg_raw = sum(self.raw_history) / len(self.raw_history)
                self.zero_offset = (
                    (1.0 - AUTO_ZERO_RATE) * self.zero_offset +
                    AUTO_ZERO_RATE * avg_raw
                )
                self.filtered_net_torque = 0.0

        corrected = raw_net_torque - self.zero_offset

        # Low-pass filter
        self.filtered_net_torque = (
            ALPHA * corrected +
            (1.0 - ALPHA) * self.filtered_net_torque
        )

        # Deadband
        if abs(self.filtered_net_torque) < NET_TORQUE_DEADBAND:
            net = 0.0
        else:
            net = self.filtered_net_torque * TORQUE_GAIN

        # EN KRITIK KISIM:
        # Motorlar kapaliyken / stop durumundayken Gazebo'ya tork gonderme.
        # Raw ve corrected veri gorunur ama simulation torku 0 olur.
        if enabled == 0:
            net = 0.0

        return corrected, net

    def parse_line(self, line):
        # Yeni format:
        # DATA,time_ms,f1_N,f2_N,tork1_Nm,tork2_Nm,tork_net_Nm,pwm1,pwm2,enabled
        if line.startswith("DATA,"):
            parts = line.split(",")

            if len(parts) < 10:
                return None

            f1 = float(parts[2])
            f2 = float(parts[3])
            torque1 = float(parts[4])
            torque2 = float(parts[5])
            raw_net_torque = float(parts[6])
            pwm1 = int(parts[7])
            pwm2 = int(parts[8])
            enabled = int(parts[9])

            return f1, f2, torque1, torque2, raw_net_torque, pwm1, pwm2, enabled

        # Eski format:
        # f1 f2 tnet pwm1 pwm2
        parts = line.split()

        if len(parts) >= 5:
            f1 = float(parts[0])
            f2 = float(parts[1])
            raw_net_torque = float(parts[2])
            pwm1 = int(float(parts[3]))
            pwm2 = int(float(parts[4]))

            torque1 = f1 * 0.03
            torque2 = f2 * 0.03
            enabled = 0 if pwm1 <= 1000 and pwm2 <= 1000 else 1

            return f1, f2, torque1, torque2, raw_net_torque, pwm1, pwm2, enabled

        return None

    def read_serial(self):
        try:
            line = self.ser.readline().decode("utf-8", errors="ignore").strip()

            if not line:
                return

            if line.startswith("["):
                self.get_logger().info(line)
                return

            parsed = self.parse_line(line)

            if parsed is None:
                return

            f1, f2, torque1, torque2, raw_net_torque, pwm1, pwm2, enabled = parsed

            corrected_net_torque, net_torque = self.process_torque(
                raw_net_torque,
                enabled
            )

            self.publish_all(
                f1, f2,
                torque1, torque2,
                raw_net_torque,
                corrected_net_torque,
                net_torque,
                pwm1, pwm2,
                enabled
            )

            now = time.monotonic()
            if now - self.last_log_time > 1.5:
                self.last_log_time = now
                self.get_logger().info(
                    f"raw={raw_net_torque:.6f} | "
                    f"offset={self.zero_offset:.6f} | "
                    f"corr={corrected_net_torque:.6f} | "
                    f"net={net_torque:.6f} | "
                    f"enabled={enabled}"
                )

        except Exception as e:
            self.get_logger().warn(f"Serial parse error: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = ESP32LoadcellBridge()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
