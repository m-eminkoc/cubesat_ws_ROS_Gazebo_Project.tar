#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from tf2_msgs.msg import TFMessage


def wrap_pi(a):
    return math.atan2(math.sin(a), math.cos(a))


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def yaw_from_quat(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def smoothstep(s):
    s = clamp(s, 0.0, 1.0)
    return 3.0 * s * s - 2.0 * s * s * s


class GazeboYawPDController(Node):
    def __init__(self):
        super().__init__('gazebo_yaw_pd_controller')

        self.current_yaw = None
        self.prev_yaw = None
        self.prev_time = None
        self.yaw_rate = 0.0

        self.ref_yaw = 0.0
        self.start_ref = 0.0
        self.goal_yaw = 0.0
        self.traj_start_time = None

        # Görsel ama güvenli demo: hedefe 8 saniyede gitmeye çalışır
        self.traj_duration = 8.0

        # Güvenli gainler
        self.Kp = 0.004
        self.Kd = 0.012
        self.max_torque = 0.003

        self.create_subscription(Float32, '/cubesat/target_yaw_deg', self.target_callback, 10)
        self.create_subscription(TFMessage, '/world/space_attitude_control/pose/info', self.pose_callback, 10)

        self.torque_pub = self.create_publisher(Float32, '/reaction_wheel/net_torque', 10)
        self.current_yaw_pub = self.create_publisher(Float32, '/cubesat/current_yaw_deg', 10)
        self.ref_yaw_pub = self.create_publisher(Float32, '/cubesat/reference_yaw_deg', 10)
        self.error_pub = self.create_publisher(Float32, '/cubesat/yaw_error_deg', 10)

        self.timer = self.create_timer(0.05, self.control_step)

        self.get_logger().info("SAFE YAW ATTITUDE CONTROLLER STARTED")
        self.get_logger().info("Target example: ros2 topic pub /cubesat/target_yaw_deg std_msgs/msg/Float32 '{data: 60.0}' -1")
        self.get_logger().info(f"Duration={self.traj_duration}s, Kp={self.Kp}, Kd={self.Kd}, max_torque={self.max_torque}")

    def target_callback(self, msg):
        self.start_ref = self.ref_yaw
        self.goal_yaw = math.radians(float(msg.data))
        self.traj_start_time = self.get_clock().now().nanoseconds * 1e-9
        self.get_logger().info(f"New target yaw: {msg.data:.2f} deg")

    def pose_callback(self, msg):
        if len(msg.transforms) == 0:
            return

        # Model pose genelde z=2.0 olan transform.
        # Marker/link seçilmesin diye z=2.0'a en yakın ve x-y'ye en yakın transform seçiliyor.
        chosen = min(
            msg.transforms,
            key=lambda t: abs(t.transform.translation.z - 2.0)
            + 0.1 * abs(t.transform.translation.x)
            + 0.1 * abs(t.transform.translation.y)
        )

        now = self.get_clock().now().nanoseconds * 1e-9
        yaw = yaw_from_quat(chosen.transform.rotation)

        if self.prev_yaw is not None and self.prev_time is not None:
            dt = now - self.prev_time
            if dt > 1e-4:
                self.yaw_rate = wrap_pi(yaw - self.prev_yaw) / dt

        self.current_yaw = yaw
        self.prev_yaw = yaw
        self.prev_time = now

        out = Float32()
        out.data = math.degrees(yaw)
        self.current_yaw_pub.publish(out)

    def update_reference(self):
        if self.traj_start_time is None:
            return

        now = self.get_clock().now().nanoseconds * 1e-9
        s = (now - self.traj_start_time) / self.traj_duration
        p = smoothstep(s)

        delta = wrap_pi(self.goal_yaw - self.start_ref)
        self.ref_yaw = wrap_pi(self.start_ref + p * delta)

    def control_step(self):
        self.update_reference()

        ref_msg = Float32()
        ref_msg.data = math.degrees(self.ref_yaw)
        self.ref_yaw_pub.publish(ref_msg)

        torque_msg = Float32()

        if self.current_yaw is None:
            torque_msg.data = 0.0
            self.torque_pub.publish(torque_msg)
            return

        error = wrap_pi(self.ref_yaw - self.current_yaw)

        torque = self.Kp * error - self.Kd * self.yaw_rate
        torque = clamp(torque, -self.max_torque, self.max_torque)

        if abs(error) < math.radians(0.5) and abs(self.yaw_rate) < math.radians(1.0):
            torque = 0.0

        torque_msg.data = float(torque)
        self.torque_pub.publish(torque_msg)

        err_msg = Float32()
        err_msg.data = math.degrees(error)
        self.error_pub.publish(err_msg)


def main():
    rclpy.init()
    node = GazeboYawPDController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    stop = Float32()
    stop.data = 0.0
    node.torque_pub.publish(stop)

    node.destroy_node()

    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
