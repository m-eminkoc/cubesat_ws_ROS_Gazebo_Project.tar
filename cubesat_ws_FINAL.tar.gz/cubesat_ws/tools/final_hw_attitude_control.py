#!/usr/bin/env python3
import argparse
import math
import subprocess
import time
import serial


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def sign(x):
    return 1.0 if x >= 0 else -1.0


def set_gazebo_yaw(world, model, yaw_rad, z=0.0):
    qz = math.sin(yaw_rad / 2.0)
    qw = math.cos(yaw_rad / 2.0)

    # Terminalde elle calisan komutun aynisini shell olarak basiyoruz.
    cmd = (
        f"gz service -s /world/{world}/set_pose/blocking "
        f"--reqtype gz.msgs.Pose "
        f"--reptype gz.msgs.Boolean "
        f"--timeout 2000 "
        f"--req 'name: \"{model}\" "
        f"position {{x: 0 y: 0 z: {z:.4f}}} "
        f"orientation {{x: 0 y: 0 z: {qz:.8f} w: {qw:.8f}}}'"
    )

    try:
        r = subprocess.run(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=3.0
        )

        # Hata varsa artik sessiz gecmiyoruz.
        if r.returncode != 0:
            print()
            print("[GAZEBO SET_POSE ERROR]")
            print(r.stderr.strip())

    except Exception as e:
        print()
        print("[GAZEBO SET_POSE EXCEPTION]", e)


def send_cmd(ser, cmd):
    ser.write((cmd.strip() + "\n").encode())


def parse_esp32_line(line):
    """
    ESP32 format:
    F1_N F2_N Tnet_Nm PWM1 PWM2
    """
    parts = line.strip().split()
    if len(parts) < 5:
        return None

    try:
        f1 = float(parts[0])
        f2 = float(parts[1])
        tau = float(parts[2])
        pwm1 = int(float(parts[3]))
        pwm2 = int(float(parts[4]))
        return f1, f2, tau, pwm1, pwm2
    except Exception:
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=float, required=True, help="Target angle in degrees")
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--max-time", type=float, default=45.0)

    parser.add_argument("--world", default="space_torque_test")
    parser.add_argument("--model", default="cubesat")
    parser.add_argument("--z", type=float, default=0.0)

    # Torktan görsel açısal hız üretimi
    parser.add_argument("--torque-gain", type=float, default=2500.0)  # deg/s per Nm
    parser.add_argument("--max-speed", type=float, default=8.0)       # deg/s
    parser.add_argument("--tau-deadband", type=float, default=0.0008) # Nm

    args = parser.parse_args()

    target_deg = float(args.target)
    target_rad = math.radians(target_deg)

    yaw = 0.0
    direction = sign(target_deg)

    if direction > 0:
        pwm_cmd = "p 1085 1080"
    else:
        pwm_cmd = "p 1080 1085"

    print("[INFO] FINAL ATTITUDE CONTROL")
    print("[INFO] Target:", target_deg, "deg")
    print("[INFO] Motor cmd:", pwm_cmd)
    print("[INFO] Gazebo motor aktif olmadan ve tork olcmeden DONMEYECEK.")
    print("[INFO] Hedef aci gecilmeyecek; hedefte motor stop.")

    print("[INFO] Serial aciliyor:", args.port)
    ser = serial.Serial(args.port, args.baud, timeout=0.03)

    print("[INFO] ESP32 reset/arm/tare icin 20 saniye bekleniyor...")
    time.sleep(20.0)

    # Başlangıçta Gazebo'yu 0 dereceye al
    set_gazebo_yaw(args.world, args.model, 0.0, args.z)

    print("[INFO] Neutral tork olculuyor. Motorlar calismayacak...")
    neutral_samples = []
    t_neutral = time.time()

    while time.time() - t_neutral < 2.0:
        while ser.in_waiting:
            line = ser.readline().decode(errors="ignore").strip()
            data = parse_esp32_line(line)
            if data:
                _, _, tau_raw, pwm1, pwm2 = data
                if pwm1 == 1000 and pwm2 == 1000:
                    neutral_samples.append(tau_raw)
        time.sleep(0.01)

    if len(neutral_samples) > 0:
        tau_neutral = sum(neutral_samples) / len(neutral_samples)
    else:
        tau_neutral = 0.0

    print(f"[INFO] tau_neutral = {tau_neutral:+.6f} Nm")
    print("[INFO] Kontrol basliyor...")

    latest_tau_raw = 0.0
    latest_tau_clean = 0.0
    latest_pwm1 = 1000
    latest_pwm2 = 1000

    t_start = time.time()
    t_prev = time.time()
    last_send = 0.0
    last_pose = 0.0

    try:
        while True:
            now = time.time()
            dt = now - t_prev
            t_prev = now

            if dt <= 0.0 or dt > 0.2:
                dt = 0.03

            # ESP32'ye p komutunu surekli yolla
            if now - last_send >= 0.20:
                send_cmd(ser, pwm_cmd)
                last_send = now

            # ESP32 oku
            while ser.in_waiting:
                line = ser.readline().decode(errors="ignore").strip()

                if line.startswith("["):
                    print("\n" + line)
                    continue

                data = parse_esp32_line(line)
                if data:
                    _, _, latest_tau_raw, latest_pwm1, latest_pwm2 = data
                    latest_tau_clean = latest_tau_raw - tau_neutral

            # MOTOR GERCEKTEN CALISIYOR MU?
            # 1000/1000 iken HAYIR
            # 1080/1080 bias iken HAYIR
            # 1081/1080 veya 1080/1081 gibi diferansiyel baslayinca EVET
            motor_active = (
                max(latest_pwm1, latest_pwm2) >= 1081 and
                abs(latest_pwm1 - latest_pwm2) >= 1
            )

            torque_active = abs(latest_tau_clean) >= args.tau_deadband

            # Sadece motor aktif + tork aktif ise Gazebo donsun
            if motor_active and torque_active:
                remaining_deg = target_deg - math.degrees(yaw)

                # Hedefe geldiysek daha fazla dondurme
                if abs(remaining_deg) > 0.5:
                    speed_deg_s = abs(latest_tau_clean) * args.torque_gain
                    speed_deg_s = clamp(speed_deg_s, 0.0, args.max_speed)

                    step_deg = speed_deg_s * dt

                    # HEDEFİ GEÇMEYİ ENGELLE
                    if step_deg >= abs(remaining_deg):
                        yaw = target_rad
                    else:
                        yaw += math.radians(sign(remaining_deg) * step_deg)

                    # Gazebo pose update
                    if now - last_pose >= 0.08:
                        set_gazebo_yaw(args.world, args.model, yaw, args.z)
                        last_pose = now

            yaw_deg = math.degrees(yaw)
            err_deg = target_deg - yaw_deg

            print(
                f"yaw={yaw_deg:+6.2f} deg | "
                f"target={target_deg:+6.2f} deg | "
                f"err={err_deg:+6.2f} deg | "
                f"tau_raw={latest_tau_raw:+.5f} | "
                f"tau_clean={latest_tau_clean:+.5f} | "
                f"PWM={latest_pwm1},{latest_pwm2} | "
                f"motor={motor_active} | torque={torque_active}",
                end="\r"
            )

            # Hedefe geldiysek stop
            if abs(err_deg) <= 0.5:
                print()
                print("[DONE] Hedef aciya gelindi. Motorlar stop.")
                send_cmd(ser, "s")
                time.sleep(0.1)
                send_cmd(ser, "s")
                set_gazebo_yaw(args.world, args.model, target_rad, args.z)
                break

            if now - t_start >= args.max_time:
                print()
                print("[WARN] Max sure doldu. Motorlar stop.")
                send_cmd(ser, "s")
                time.sleep(0.1)
                send_cmd(ser, "s")
                break

            time.sleep(0.02)

    except KeyboardInterrupt:
        print()
        print("[INFO] CTRL+C geldi. Motorlar stop.")
        send_cmd(ser, "s")
        time.sleep(0.1)
        send_cmd(ser, "s")

    ser.close()


if __name__ == "__main__":
    main()
