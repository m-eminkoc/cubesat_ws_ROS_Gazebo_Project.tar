#!/usr/bin/env bash
pkill -f "gz sim" 2>/dev/null
pkill -f "ruby /opt/ros/jazzy/opt/gz_tools_vendor/bin/gz" 2>/dev/null

cd ~/cubesat_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash

export GZ_SIM_RESOURCE_PATH=$GZ_SIM_RESOURCE_PATH:$HOME/cubesat_ws/src:$HOME/cubesat_ws/install/cubesat_description/share

gz sim -r -v 4 ~/cubesat_ws/src/cubesat_description/worlds/space_attitude_control.sdf
