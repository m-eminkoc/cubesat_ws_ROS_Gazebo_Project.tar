#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String


class GazeboAngleDemoNode(Node):
    def __init__(self):
        super().__init__('gazebo_angle_demo_node')

        self.world = 'space'
        self.model = 'cubesat'
        self.z_height = 1.0

        self.current_yaw = 0.0
        self.target_yaw = 0.0

        # Demo rotation speed limit
        self.max_yaw_rate_deg = 25.0
        self.max_yaw_rate = math.radians(self.max_yaw_rate_deg)

        self.last_time = self.get_clock().now()

        self.create_subscription(
            Float32,
            '/cubesat/target_yaw_deg',
            self.target_callback,
            10
        )

        self.yaw_pub = self.create_publisher(Float32, '/cubesat/current_yaw_deg', 10)
        self.mode_pub = self.create_publisher(String, '/cubesat/control_mode', 10)

        self.timer = self.create_timer(0.05, self.update)

        self.get_logger().info('Angle demo node started.')
        self.get_logger().info('Send target angle to: /cubesat/target_yaw_deg')

    def wrap_pi(self, angle):
        return (angle + math.pi) % (2.0 * math.pi) - math.pi

    def clamp(self, value, min_value, max_value):
        return max(min(value, max_value), min_value)

    def target_callback(self, msg):
        self.target_yaw = math.radians(float(msg.data))
        self.target_yaw = self.wrap_pi(self.target_yaw)
        self.get_logger().info(f'Target yaw = {float(msg.data):.2f} deg')

    def update(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        if dt <= 0.0 or dt > 0.5:
            dt = 0.05

        error = self.wrap_pi(self.target_yaw - self.current_yaw)

        max_step = self.max_yaw_rate * dt
        step = self.clamp(error, -max_step, max_step)

        self.current_yaw = self.wrap_pi(self.current_yaw + step)

        qz = math.sin(self.current_yaw / 2.0)
        qw = math.cos(self.current_yaw / 2.0)

        req = (
            f'name: "{self.model}" '
            f'position {{ x: 0 y: 0 z: {self.z_height} }} '
            f'orientation {{ x: 0 y: 0 z: {qz} w: {qw} }}'
        )

        cmd = [
            'gz', 'service',
            '-s', f'/world/{self.world}/set_pose',
            '--reqtype', 'gz.msgs.Pose',
            '--reptype', 'gz.msgs.Boolean',
            '--timeout', '100',
            '--req', req
        ]

        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.2
            )
        except Exception:
            pass

        yaw_msg = Float32()
        yaw_msg.data = math.degrees(self.current_yaw)
        self.yaw_pub.publish(yaw_msg)

        mode_msg = String()
        mode_msg.data = 'angle_setpoint_demo'
        self.mode_pub.publish(mode_msg)


def main():
    rclpy.init()
    node = GazeboAngleDemoNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
