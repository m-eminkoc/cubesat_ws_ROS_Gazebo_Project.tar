#!/usr/bin/env python3
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class GazeboRosTorqueBridge(Node):
    def __init__(self):
        super().__init__('gazebo_ros_torque_bridge')

        self.world_name = "space_attitude_control"
        self.entity_name = "cubesat"
        self.entity_type = "MODEL"

        self.latest_torque = 0.0
        self.max_torque = 0.003

        self.create_subscription(
            Float32,
            '/reaction_wheel/net_torque',
            self.torque_callback,
            10
        )

        self.timer = self.create_timer(0.05, self.apply_torque)

        self.get_logger().info("SAFE instantaneous Gazebo torque bridge started.")
        self.get_logger().info("Persistent torque is DISABLED.")
        self.get_logger().info("Listening: /reaction_wheel/net_torque")
        self.get_logger().info("Applying instantaneous torque to MODEL: cubesat")
        self.get_logger().info(f"Torque limit: +/- {self.max_torque} N.m")

    def torque_callback(self, msg):
        torque = float(msg.data)
        torque = max(-self.max_torque, min(self.max_torque, torque))
        self.latest_torque = torque

    def apply_torque(self):
        if abs(self.latest_torque) < 1e-9:
            return

        req = (
            f'entity {{ name: "{self.entity_name}" type: {self.entity_type} }} '
            f'wrench {{ torque {{ x: 0 y: 0 z: {self.latest_torque} }} }}'
        )

        subprocess.run(
            [
                "gz", "topic",
                "-t", f"/world/{self.world_name}/wrench",
                "-m", "gz.msgs.EntityWrench",
                "-p", req
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )


def main():
    rclpy.init()
    node = GazeboRosTorqueBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
