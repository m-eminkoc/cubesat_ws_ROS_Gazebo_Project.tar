import math
import subprocess
import time


MODEL_NAME = "cubesat"
WORLD_NAME = "space"

# CubeSat position in Gazebo
X = 0.0
Y = 0.0
Z = 0.20

# Yaw demo parameters
YAW_AMPLITUDE = 0.8   # radian, about 45 degrees
YAW_FREQ = 0.35       # rad/s


def send_pose(yaw):
    qz = math.sin(yaw / 2.0)
    qw = math.cos(yaw / 2.0)

    req = (
        f'name: "{MODEL_NAME}" '
        f'position {{x: {X} y: {Y} z: {Z}}} '
        f'orientation {{x: 0 y: 0 z: {qz} w: {qw}}}'
    )

    subprocess.run(
        [
            "gz", "service",
            "-s", f"/world/{WORLD_NAME}/set_pose",
            "--reqtype", "gz.msgs.Pose",
            "--reptype", "gz.msgs.Boolean",
            "--timeout", "100",
            "--req", req,
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def main():
    print("Gazebo single-axis yaw attitude demo started.")
    print("Press CTRL+C to stop.")

    t0 = time.time()

    try:
        while True:
            t = time.time() - t0

            # Same-axis counter-rotating reaction wheel pair:
            # net torque difference creates yaw attitude motion.
            yaw = YAW_AMPLITUDE * math.sin(YAW_FREQ * t)

            send_pose(yaw)
            time.sleep(0.05)  # 20 Hz

    except KeyboardInterrupt:
        print("Stopped.")


if __name__ == "__main__":
    main()
