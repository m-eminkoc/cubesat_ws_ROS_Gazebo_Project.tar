#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String


class GazeboSpinDemoNode(Node):
    def __init__(self):
        super().__init__('gazebo_spin_demo_node')

        self.world = 'space'
        self.model = 'cubesat'
        self.z_height = 1.0

        self.yaw = 0.0
        self.torque_cmd = 0.0

        # Demo parameters
        self.torque_limit = 0.02       # incoming command is saturated
        self.deadband = 0.0005
        self.max_yaw_rate_deg_s = 120.0 # visible rotation speed at max command

        self.last_time = self.get_clock().now()

        self.create_subscription(
            Float32,
            '/reaction_wheel/net_torque',
            self.torque_callback,
            10
        )

        self.yaw_pub = self.create_publisher(Float32, '/cubesat/current_yaw_deg', 10)
        self.rate_pub = self.create_publisher(Float32, '/cubesat/yaw_rate_deg_s', 10)
        self.mode_pub = self.create_publisher(String, '/cubesat/control_mode', 10)

        self.timer = self.create_timer(0.05, self.update)
        self.print_timer = self.create_timer(1.0, self.print_status)

        self.get_logger().info('Spin demo node started.')
        self.get_logger().info('Send torque to /reaction_wheel/net_torque')
        self.get_logger().info('Positive torque = one direction, negative torque = opposite direction.')

    def torque_callback(self, msg):
        self.torque_cmd = float(msg.data)

    def clamp(self, value, min_value, max_value):
        return max(min(value, max_value), min_value)

    def wrap_pi(self, angle):
        return (angle + math.pi) % (2.0 * math.pi) - math.pi

    def update(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        if dt <= 0.0 or dt > 0.5:
            dt = 0.05

        torque_sat = self.clamp(self.torque_cmd, -self.torque_limit, self.torque_limit)

        if abs(torque_sat) < self.deadband:
            yaw_rate = 0.0
        else:
            # Map torque command to visible yaw rate for demo
            ratio = torque_sat / self.torque_limit
            yaw_rate = math.radians(self.max_yaw_rate_deg_s) * ratio

        self.yaw = self.wrap_pi(self.yaw + yaw_rate * dt)

        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{self.model}" '
            f'position {{ x: 0 y: 0 z: {self.z_height} }} '
            f'orientation {{ x: 0 y: 0 z: {qz} w: {qw} }}'
        )

        cmd = [
            'gz', 'service',
            '-s', f'/world/{self.world}/set_pose',
            '--reqtype', 'gz.msgs.Pose',
            '--reptype', 'gz.msgs.Boolean',
            '--timeout', '100',
            '--req', req
        ]

        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.2
            )
        except Exception as e:
            self.get_logger().warn(f'Gazebo set_pose failed: {e}')

        yaw_msg = Float32()
        yaw_msg.data = math.degrees(self.yaw)
        self.yaw_pub.publish(yaw_msg)

        rate_msg = Float32()
        rate_msg.data = math.degrees(yaw_rate)
        self.rate_pub.publish(rate_msg)

        mode_msg = String()
        mode_msg.data = 'continuous_yaw_rotation_demo'
        self.mode_pub.publish(mode_msg)

    def print_status(self):
        self.get_logger().info(
            f'torque_cmd={self.torque_cmd:.4f}, yaw={math.degrees(self.yaw):.2f} deg'
        )


def main():
    rclpy.init()
    node = GazeboSpinDemoNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
