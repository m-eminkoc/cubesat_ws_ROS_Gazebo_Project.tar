#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String


class GazeboRotationDemoNode(Node):
    def __init__(self):
        super().__init__('gazebo_rotation_demo_node')

        # CAD-based yaw inertia from Autodesk Inventor
        self.Izz = 0.002718905  # kg*m^2

        # Demo safety parameters
        self.torque_limit = 0.02       # N*m
        self.rate_limit = 0.04         # N*m/s
        self.filter_alpha = 0.20
        self.damping = 0.985           # close to space-like but stable

        self.world = 'space'
        self.model = 'cubesat'
        self.z_height = 1.0

        self.torque_raw = 0.0
        self.torque_filtered = 0.0
        self.torque_out = 0.0

        self.yaw = 0.0
        self.omega = 0.0
        self.last_time = self.get_clock().now()

        self.create_subscription(
            Float32,
            '/reaction_wheel/net_torque',
            self.torque_callback,
            10
        )

        self.yaw_pub = self.create_publisher(Float32, '/cubesat/current_yaw_deg', 10)
        self.omega_pub = self.create_publisher(Float32, '/cubesat/yaw_rate_deg_s', 10)
        self.mode_pub = self.create_publisher(String, '/cubesat/control_mode', 10)

        self.timer = self.create_timer(0.05, self.update_pose)

        self.get_logger().info('Rotation demo node started.')
        self.get_logger().info('Send torque to: /reaction_wheel/net_torque')
        self.get_logger().info('Positive torque rotates one direction, negative torque rotates opposite direction.')

    def torque_callback(self, msg):
        self.torque_raw = float(msg.data)

    def clamp(self, value, min_value, max_value):
        return max(min(value, max_value), min_value)

    def wrap_pi(self, angle):
        return (angle + math.pi) % (2.0 * math.pi) - math.pi

    def update_pose(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        if dt <= 0.0 or dt > 0.5:
            dt = 0.05

        # Low-pass filter
        self.torque_filtered = (
            self.filter_alpha * self.torque_raw
            + (1.0 - self.filter_alpha) * self.torque_filtered
        )

        # Saturation
        torque_sat = self.clamp(
            self.torque_filtered,
            -self.torque_limit,
            self.torque_limit
        )

        # Rate limit
        max_step = self.rate_limit * dt
        delta = self.clamp(torque_sat - self.torque_out, -max_step, max_step)
        self.torque_out += delta

        # Yaw dynamics: Izz * yaw_ddot = torque
        yaw_acc = self.torque_out / self.Izz
        self.omega += yaw_acc * dt
        self.omega *= self.damping
        self.yaw += self.omega * dt
        self.yaw = self.wrap_pi(self.yaw)

        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{self.model}" '
            f'position {{ x: 0 y: 0 z: {self.z_height} }} '
            f'orientation {{ x: 0 y: 0 z: {qz} w: {qw} }}'
        )

        cmd = [
            'gz', 'service',
            '-s', f'/world/{self.world}/set_pose',
            '--reqtype', 'gz.msgs.Pose',
            '--reptype', 'gz.msgs.Boolean',
            '--timeout', '100',
            '--req', req
        ]

        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.2
            )
        except Exception:
            pass

        yaw_msg = Float32()
        yaw_msg.data = math.degrees(self.yaw)
        self.yaw_pub.publish(yaw_msg)

        omega_msg = Float32()
        omega_msg.data = math.degrees(self.omega)
        self.omega_pub.publish(omega_msg)

        mode_msg = String()
        mode_msg.data = 'reaction_wheel_rotation_demo'
        self.mode_pub.publish(mode_msg)


def main():
    rclpy.init()
    node = GazeboRotationDemoNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
