import math
import subprocess
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


MODEL_NAME = "cubesat"
WORLD_NAME = "space"

X = 0.0
Y = 0.0
Z = 0.20

# Güvenli demo ayarları
DEADBAND = 0.0025       # Boşta kalan küçük torkları tamamen yok say
VEL_GAIN = 85.0        # Tork -> yaw hızı kazancı
MAX_YAW_RATE = 0.9     # rad/s, hız limiti

STOP_DECAY = 0.15      # tork yoksa hızlıca durdur


class GazeboManualYawNode(Node):
    def __init__(self):
        super().__init__("gazebo_manual_yaw_node")

        self.input_torque = 0.0
        self.yaw = 0.0
        self.yaw_rate = 0.0
        self.last_msg_time = time.monotonic()

        self.last_time = self.get_clock().now()

        self.create_subscription(
            Float32,
            "/reaction_wheel/corrected_net_torque",
            self.torque_callback,
            10
        )

        self.timer = self.create_timer(0.05, self.update)

        self.get_logger().info("STABLE manual yaw node started.")
        self.get_logger().info("Listening: /reaction_wheel/corrected_net_torque")
        self.get_logger().info(f"Deadband = {DEADBAND} Nm")

    def torque_callback(self, msg):
        self.input_torque = float(msg.data)
        self.last_msg_time = time.monotonic()

    def send_pose(self):
        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{MODEL_NAME}" '
            f'position {{x: {X} y: {Y} z: {Z}}} '
            f'orientation {{x: 0 y: 0 z: {qz} w: {qw}}}'
        )

        subprocess.run(
            [
                "gz", "service",
                "-s", f"/world/{WORLD_NAME}/set_pose/blocking",
                "--reqtype", "gz.msgs.Pose",
                "--reptype", "gz.msgs.Boolean",
                "--timeout", "500",
                "--req", req,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def update(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        if dt <= 0.0 or dt > 0.2:
            return

        torque = self.input_torque

        # Eğer veri kesildiyse dur
        if time.monotonic() - self.last_msg_time > 0.4:
            torque = 0.0

        # Deadband: küçük residual torkları yok say
        if abs(torque) < DEADBAND:
            self.yaw_rate *= STOP_DECAY

            if abs(self.yaw_rate) < 0.01:
                self.yaw_rate = 0.0
        else:
            # Artık ivme biriktirmiyoruz.
            # Torku direkt güvenli yaw hızına çeviriyoruz.
            effective_torque = abs(torque) - DEADBAND
            commanded_rate = VEL_GAIN * effective_torque

            if torque < 0:
                commanded_rate *= -1.0

            if commanded_rate > MAX_YAW_RATE:
                commanded_rate = MAX_YAW_RATE
            elif commanded_rate < -MAX_YAW_RATE:
                commanded_rate = -MAX_YAW_RATE

            self.yaw_rate = commanded_rate

        self.yaw += self.yaw_rate * dt
        self.send_pose()


def main(args=None):
    rclpy.init(args=args)
    node = GazeboManualYawNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
