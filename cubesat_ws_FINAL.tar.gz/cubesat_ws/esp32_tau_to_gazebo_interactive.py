#!/usr/bin/env python3
import argparse
import re
import subprocess
import time
import serial
import sys
import select


def parse_tau(line):
    line = line.strip()
    if not line:
        return None

    low = line.lower()

    if "tau_nm" not in low:
        return None

    nums = re.findall(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?', line)
    if not nums:
        return None

    return float(nums[-1])


def send_gazebo_torque(world, model, torque):
    topic = f"/world/{world}/wrench/persistent"

    payload = (
        f'entity {{ name: "{model}" type: MODEL }} '
        f'wrench {{ torque {{ x: 0 y: 0 z: {torque:.9f} }} }}'
    )

    subprocess.run(
        [
            "gz", "topic",
            "-t", topic,
            "-m", "gz.msgs.EntityWrench",
            "-p", payload
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=1.0
    )


def clear_gazebo_torque(world, model):
    topic = f"/world/{world}/wrench/clear"
    payload = f'name: "{model}" type: MODEL'

    subprocess.run(
        [
            "gz", "topic",
            "-t", topic,
            "-m", "gz.msgs.Entity",
            "-p", payload
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=1.0
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--world", default="space_torque_test")
    parser.add_argument("--model", default="cubesat")
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--deadband", type=float, default=0.00005)
    parser.add_argument("--alpha", type=float, default=0.35)
    parser.add_argument("--rate", type=float, default=10.0)
    parser.add_argument("--invert", action="store_true")
    args = parser.parse_args()

    print("ESP32 TAU_NM → Gazebo torque bridge başladı ✅")
    print(f"Port   : {args.port}")
    print(f"World  : {args.world}")
    print(f"Model  : {args.model}")
    print(f"Scale  : {args.scale}")
    print("")
    print("Bu terminalden komut gönderebilirsin:")
    print("  t + Enter  = tare")
    print("  e + Enter  = motor enable")
    print("  s + Enter  = stop")
    print("  Ctrl+C     = çıkış")
    print("")
    print("Arduino Serial Monitor kapalı olmalı.")
    print("")

    ser = serial.Serial(args.port, args.baud, timeout=0.03)
    time.sleep(2.0)

    tau_f = 0.0
    last_send = 0.0
    period = 1.0 / args.rate

    try:
        while True:
            # Terminalden komut geldiyse ESP32'ye gönder
            if select.select([sys.stdin], [], [], 0)[0]:
                cmd = sys.stdin.readline().strip()

                if cmd in ["t", "T", "e", "E", "s", "S"]:
                    ser.write(cmd.encode())
                    ser.flush()
                    print(f"[PC→ESP32] Komut gönderildi: {cmd}")
                elif cmd:
                    print("[UYARI] Sadece t, e veya s gönder.")

            # ESP32 serial oku
            raw = ser.readline().decode(errors="ignore").strip()

            if raw:
                # ESP32 bilgi satırlarını da gösterelim
                if raw.startswith("["):
                    print(raw)

            tau = parse_tau(raw)

            if tau is None:
                continue

            if args.invert:
                tau = -tau

            if abs(tau) < args.deadband:
                tau = 0.0

            tau_f = args.alpha * tau + (1.0 - args.alpha) * tau_f
            gazebo_tau = tau_f * args.scale

            now = time.time()
            if now - last_send >= period:
                send_gazebo_torque(args.world, args.model, gazebo_tau)
                last_send = now

                print(
                    f"ESP32={tau:+.8f} Nm | "
                    f"filtered={tau_f:+.8f} Nm | "
                    f"Gazebo={gazebo_tau:+.8f} Nm"
                )

    except KeyboardInterrupt:
        print("\nDurduruluyor...")
    finally:
        try:
            ser.write(b"s")
            ser.flush()
        except Exception:
            pass

        clear_gazebo_torque(args.world, args.model)
        ser.close()
        print("Gazebo torku temizlendi, ESP32 stop gönderildi ✅")


if __name__ == "__main__":
    main()
