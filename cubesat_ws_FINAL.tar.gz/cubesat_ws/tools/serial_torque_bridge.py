#!/usr/bin/env python3

import argparse
import time
import serial

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class SerialTorqueBridge(Node):
    def __init__(self, port, baud):
        super().__init__("serial_torque_bridge")

        self.pub = self.create_publisher(
            Float32,
            "/reaction_wheel/net_torque",
            10
        )

        self.ser = serial.Serial(port, baud, timeout=1.0)

        # Logdan aldigimiz 1080-1080 neutral offset
        self.tau_neutral = -0.0045

        # Gazebo gorunurlugu icin olcekleme
        self.scale = 30.0

        # Kucuk noise temizleme
        self.deadband = 0.0005

        # Gazebo'ya asiri tork gitmesin
        self.max_torque = 0.08

        self.last_print = time.time()

        self.get_logger().info(f"Serial port acildi: {port} @ {baud}")
        self.get_logger().info(f"tau_neutral = {self.tau_neutral:.4f} Nm")
        self.get_logger().info(f"scale = {self.scale}")
        self.get_logger().info("PWM 1000-1000 iken Gazebo torque = 0")
        self.get_logger().info("Dinleniyor...")

        self.timer = self.create_timer(0.001, self.read_serial)

    def clamp(self, x, lo, hi):
        return max(lo, min(hi, x))

    def read_serial(self):
        try:
            line = self.ser.readline().decode(errors="ignore").strip()
        except Exception as e:
            self.get_logger().warn(f"Serial okuma hatasi: {e}")
            return

        if not line:
            return

        # [CMD], [INFO] gibi satirlari gec
        if line.startswith("["):
            self.get_logger().info(line)
            return

        parts = line.split()

        if len(parts) != 5:
            return

        try:
            f1 = float(parts[0])
            f2 = float(parts[1])
            tau_raw = float(parts[2])
            pwm1 = int(float(parts[3]))
            pwm2 = int(float(parts[4]))
        except ValueError:
            return

        # Motorlar stop ise, load cell offset/salınımını Gazebo'ya sokma
        if pwm1 <= 1005 and pwm2 <= 1005:
            tau_gazebo = 0.0
            tau_clean = 0.0
        else:
            tau_clean = tau_raw - self.tau_neutral

            if abs(tau_clean) < self.deadband:
                tau_clean = 0.0

            tau_gazebo = tau_clean * self.scale
            tau_gazebo = self.clamp(
                tau_gazebo,
                -self.max_torque,
                self.max_torque
            )

        msg = Float32()
        msg.data = float(tau_gazebo)
        self.pub.publish(msg)

        now = time.time()
        if now - self.last_print > 0.5:
            self.last_print = now
            self.get_logger().info(
                f"raw={tau_raw:+.4f} Nm | clean={tau_clean:+.4f} Nm | "
                f"gazebo={tau_gazebo:+.4f} Nm | PWM={pwm1},{pwm2}"
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    args = parser.parse_args()

    rclpy.init()
    node = SerialTorqueBridge(args.port, args.baud)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.ser.close()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
