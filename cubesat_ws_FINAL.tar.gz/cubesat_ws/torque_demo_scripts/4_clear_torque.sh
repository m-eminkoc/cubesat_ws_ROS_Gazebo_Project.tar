#!/usr/bin/env bash
gz topic -t /world/space_torque_test/wrench/clear \
-m gz.msgs.Entity \
-p 'name: "cubesat" type: MODEL'

gz topic -t /world/space_torque_test/wrench/clear \
-m gz.msgs.Entity \
-p 'name: "cubesat::body_link" type: LINK'

gz topic -t /world/space_torque_test/wrench/clear \
-m gz.msgs.Entity \
-p 'name: "cubesat::base_link" type: LINK'

echo "[OK] Torque cleared."
