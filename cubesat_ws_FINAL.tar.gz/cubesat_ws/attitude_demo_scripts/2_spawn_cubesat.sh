#!/usr/bin/env bash
cd ~/cubesat_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash

xacro ~/cubesat_ws/src/cubesat_description/urdf/cubesat.urdf.xacro > /tmp/cubesat_raw.urdf

sed "s|model://cubesat_description|file://$HOME/cubesat_ws/src/cubesat_description|g" \
/tmp/cubesat_raw.urdf > /tmp/cubesat_gazebo.urdf

ros2 run ros_gz_sim create \
-world space_attitude_control \
-file /tmp/cubesat_gazebo.urdf \
-name cubesat \
-x 0 -y 0 -z 2.0
