#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32

def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi

class GazeboPoseYawNode(Node):
    def __init__(self):
        super().__init__("gazebo_pose_yaw_node")
        self.world = "space_torque_test"
        self.model = "cubesat"
        self.service = f"/world/{self.world}/set_pose"

        self.yaw = 0.0
        self.tau = 0.0

        self.sub = self.create_subscription(
            Float32,
            "/reaction_wheel/net_torque",
            self.cb,
            10
        )

        self.timer = self.create_timer(0.05, self.step)

        self.get_logger().info("T5 READY: /reaction_wheel/net_torque -> Gazebo yaw")

    def cb(self, msg):
        self.tau = float(msg.data)

    def step(self):
        # Görsel hız: tau küçük olsa bile görünür hareket versin
        if abs(self.tau) < 0.0005:
            return

        self.yaw = wrap_pi(self.yaw + self.tau * 8.0)

        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{self.model}" '
            f'position {{x: 0 y: 0 z: 0}} '
            f'orientation {{x: 0 y: 0 z: {qz:.8f} w: {qw:.8f}}}'
        )

        cmd = [
            "gz", "service",
            "-s", self.service,
            "--reqtype", "gz.msgs.Pose",
            "--reptype", "gz.msgs.Boolean",
            "--timeout", "2000",
            "--req", req
        ]

        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        self.get_logger().info(
            f"tau={self.tau:+.4f} | yaw={math.degrees(self.yaw):+.1f} deg",
            throttle_duration_sec=0.3
        )

def main():
    rclpy.init()
    node = GazeboPoseYawNode()
    rclpy.spin(node)

if __name__ == "__main__":
    main()
