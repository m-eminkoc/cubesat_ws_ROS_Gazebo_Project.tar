#!/usr/bin/env bash
gz topic -t /world/space_attitude_control/wrench/clear \
-m gz.msgs.Entity \
-p 'name: "cubesat" type: MODEL'

gz topic -t /world/space_attitude_control/wrench/clear \
-m gz.msgs.Entity \
-p 'name: "cubesat::body_link" type: LINK'

echo "[OK] Torque cleared."
