#!/usr/bin/env bash
gz service -s /world/space_attitude_control/control \
--reqtype gz.msgs.WorldControl \
--reptype gz.msgs.Boolean \
--timeout 1000 \
--req 'reset { all: true }'
