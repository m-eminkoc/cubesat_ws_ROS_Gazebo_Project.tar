# cubesat_description

Full CubeSat visual STL:
- `son_hal_dail.stl`

Extra meshes kept for reference:
- `reactionw1.stl`
- `reactionw2.stl`

The displayed reaction wheels are already part of the full visual STL.  
The URDF also includes invisible virtual reaction wheel joints:
- `virtual_reactionwheel_1_joint`
- `virtual_reactionwheel_2_joint`

These joints can be used later for ROS 2 attitude-control and load-cell torque simulation.
