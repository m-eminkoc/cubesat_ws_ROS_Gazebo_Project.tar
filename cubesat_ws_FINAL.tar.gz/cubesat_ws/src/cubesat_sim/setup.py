from setuptools import find_packages, setup

package_name = 'cubesat_sim'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='memin',
    maintainer_email='memin@example.com',
    description='CubeSat attitude simulation demo for RViz.',
    license='MIT',
    entry_points={
        'console_scripts': [
            'attitude_demo_node = cubesat_sim.attitude_demo_node:main',
        ],
    },
)
