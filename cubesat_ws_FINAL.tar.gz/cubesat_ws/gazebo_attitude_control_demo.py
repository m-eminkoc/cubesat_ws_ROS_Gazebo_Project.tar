#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def wrap_pi(a):
    return math.atan2(math.sin(a), math.cos(a))


class GazeboAttitudeControlDemo(Node):
    def __init__(self):
        super().__init__('gazebo_attitude_control_demo')

        self.model_name = "cubesat"
        self.world_name = "space"

        self.z_height = 1.0

        self.Izz = 0.02
        self.damping = 0.03

        self.Kp = 0.08
        self.Kd = 0.04
        self.max_torque = 0.04

        self.yaw = 0.0
        self.yaw_rate = 0.0
        self.target_yaw = 0.0

        self.dt = 0.05

        self.create_subscription(
            Float32,
            '/cubesat/target_yaw_deg',
            self.target_callback,
            10
        )

        self.yaw_pub = self.create_publisher(
            Float32,
            '/cubesat/current_yaw_deg',
            10
        )

        self.torque_pub = self.create_publisher(
            Float32,
            '/reaction_wheel/net_torque',
            10
        )

        self.timer = self.create_timer(self.dt, self.step)

        self.get_logger().info("Gazebo attitude control demo started.")
        self.get_logger().info("Send target yaw:")
        self.get_logger().info('ros2 topic pub /cubesat/target_yaw_deg std_msgs/msg/Float32 "{data: 90.0}" -1')

    def target_callback(self, msg):
        self.target_yaw = math.radians(msg.data)
        self.get_logger().info(f"New target yaw: {msg.data:.2f} deg")

    def step(self):
        error = wrap_pi(self.target_yaw - self.yaw)

        torque = self.Kp * error - self.Kd * self.yaw_rate
        torque = clamp(torque, -self.max_torque, self.max_torque)

        yaw_acc = (torque - self.damping * self.yaw_rate) / self.Izz
        self.yaw_rate += yaw_acc * self.dt
        self.yaw += self.yaw_rate * self.dt
        self.yaw = wrap_pi(self.yaw)

        if abs(error) < math.radians(0.5) and abs(self.yaw_rate) < math.radians(1.0):
            self.yaw = self.target_yaw
            self.yaw_rate = 0.0
            torque = 0.0

        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{self.model_name}", '
            f'position: {{x: 0, y: 0, z: {self.z_height}}}, '
            f'orientation: {{x: 0, y: 0, z: {qz}, w: {qw}}}'
        )

        subprocess.run(
            [
                "gz", "service",
                "-s", f"/world/{self.world_name}/set_pose",
                "--reqtype", "gz.msgs.Pose",
                "--reptype", "gz.msgs.Boolean",
                "--timeout", "100",
                "--req", req
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        yaw_msg = Float32()
        yaw_msg.data = math.degrees(self.yaw)
        self.yaw_pub.publish(yaw_msg)

        torque_msg = Float32()
        torque_msg.data = float(torque)
        self.torque_pub.publish(torque_msg)


def main():
    rclpy.init()
    node = GazeboAttitudeControlDemo()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
