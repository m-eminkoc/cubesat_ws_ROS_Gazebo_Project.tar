#!/usr/bin/env bash
cd ~/cubesat_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash

ros2 run ros_gz_bridge parameter_bridge \
'/world/space_attitude_control/pose/info@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V'
