import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster


def quaternion_from_euler(roll, pitch, yaw):
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)

    qx = sr * cp * cy - cr * sp * sy
    qy = cr * sp * cy + sr * cp * sy
    qz = cr * cp * sy - sr * sp * cy
    qw = cr * cp * cy + sr * sp * sy
    return qx, qy, qz, qw


class AttitudeDemoNode(rclpy.node.Node):
    def __init__(self):
        super().__init__('attitude_demo_node')
        self.tf_broadcaster = TransformBroadcaster(self)
        self.start_time = self.get_clock().now()
        self.timer = self.create_timer(0.02, self.timer_callback)
        self.get_logger().info('Single-axis counter-rotating reaction wheel demo started.')

    def timer_callback(self):
        now = self.get_clock().now()
        t = (now - self.start_time).nanoseconds * 1e-9

        # Same-axis two-motor system:
        # Motor 1 CW, Motor 2 CCW.
        # Only one attitude axis can be controlled.
        roll = 0.0
        pitch = 0.0
        yaw = 0.45 * math.sin(0.5 * t)

        qx, qy, qz, qw = quaternion_from_euler(roll, pitch, yaw)

        transform = TransformStamped()
        transform.header.stamp = now.to_msg()
        transform.header.frame_id = 'world'
        transform.child_frame_id = 'base_link'

        transform.transform.translation.x = 0.0
        transform.transform.translation.y = 0.0
        transform.transform.translation.z = 0.0

        transform.transform.rotation.x = qx
        transform.transform.rotation.y = qy
        transform.transform.rotation.z = qz
        transform.transform.rotation.w = qw

        self.tf_broadcaster.sendTransform(transform)


def main(args=None):
    rclpy.init(args=args)
    node = AttitudeDemoNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
