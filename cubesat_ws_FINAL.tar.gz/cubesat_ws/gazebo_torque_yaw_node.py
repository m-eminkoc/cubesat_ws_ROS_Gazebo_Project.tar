#!/usr/bin/env python3
import math
import subprocess
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class GazeboTorqueYawNode(Node):
    def __init__(self):
        super().__init__('gazebo_torque_yaw_node')

        # CAD inertia from Inventor
        self.Izz = 0.002718905   # kg*m^2

        # Demo safety parameters
        self.torque_limit = 0.02       # N*m saturation
        self.rate_limit = 0.04         # N*m/s rate limit
        self.filter_alpha = 0.20       # low-pass filter
        self.damping = 0.96            # visual damping for stable demo

        self.world = 'space'
        self.model = 'cubesat'
        self.z_height = 1.0

        self.torque_raw = 0.0
        self.torque_filtered = 0.0
        self.torque_out = 0.0

        self.yaw = 0.0
        self.omega = 0.0
        self.last_time = self.get_clock().now()

        self.create_subscription(
            Float32,
            '/reaction_wheel/net_torque',
            self.torque_callback,
            10
        )

        self.timer = self.create_timer(0.10, self.update_pose)

        self.get_logger().info('Listening: /reaction_wheel/net_torque')
        self.get_logger().info('Gazebo visual yaw control node started.')

    def torque_callback(self, msg):
        self.torque_raw = float(msg.data)

    def clamp(self, value, min_value, max_value):
        return max(min(value, max_value), min_value)

    def update_pose(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        if dt <= 0.0 or dt > 0.5:
            dt = 0.1

        # Low-pass filter
        self.torque_filtered = (
            self.filter_alpha * self.torque_raw
            + (1.0 - self.filter_alpha) * self.torque_filtered
        )

        # Saturation
        torque_sat = self.clamp(
            self.torque_filtered,
            -self.torque_limit,
            self.torque_limit
        )

        # Rate limit
        max_step = self.rate_limit * dt
        delta = self.clamp(torque_sat - self.torque_out, -max_step, max_step)
        self.torque_out += delta

        # Simple yaw dynamics: Izz * yaw_ddot = torque
        yaw_acc = self.torque_out / self.Izz
        self.omega += yaw_acc * dt
        self.omega *= self.damping
        self.yaw += self.omega * dt

        # Keep yaw angle bounded
        self.yaw = (self.yaw + math.pi) % (2.0 * math.pi) - math.pi

        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)

        req = (
            f'name: "{self.model}" '
            f'position {{ x: 0 y: 0 z: {self.z_height} }} '
            f'orientation {{ x: 0 y: 0 z: {qz} w: {qw} }}'
        )

        cmd = [
            'gz', 'service',
            '-s', f'/world/{self.world}/set_pose',
            '--reqtype', 'gz.msgs.Pose',
            '--reptype', 'gz.msgs.Boolean',
            '--timeout', '100',
            '--req', req
        ]

        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.2
            )
        except Exception:
            pass


def main():
    rclpy.init()
    node = GazeboTorqueYawNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
