#!/usr/bin/env bash
TORQUE=${1:-0.0001}
DURATION=${2:-2}

echo "[INFO] Applying persistent MODEL torque"
echo "[INFO] Torque z = ${TORQUE} N.m"
echo "[INFO] Duration = ${DURATION} s"

gz topic -t /world/space_torque_test/wrench/persistent \
-m gz.msgs.EntityWrench \
-p "entity { name: \"cubesat\" type: MODEL } wrench { torque { x: 0 y: 0 z: ${TORQUE} } }"

sleep ${DURATION}

gz topic -t /world/space_torque_test/wrench/clear \
-m gz.msgs.Entity \
-p 'name: "cubesat" type: MODEL'

echo "[OK] Persistent torque cleared."
