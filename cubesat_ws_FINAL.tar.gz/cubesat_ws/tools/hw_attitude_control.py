#!/usr/bin/env python3

import argparse
import math
import time

import serial

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from tf2_msgs.msg import TFMessage


def wrap_pi(a):
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


def quat_to_yaw(q):
    x = q.x
    y = q.y
    z = q.z
    w = q.w

    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)

    return math.atan2(siny_cosp, cosy_cosp)


class HardwareAttitudeControl(Node):
    def __init__(self, args):
        super().__init__("hw_attitude_control")

        self.args = args

        # ================= SERIAL =================
        self.ser = serial.Serial(args.port, args.baud, timeout=0.0)
        time.sleep(1.0)

        # ================= ROS =================
        self.pose_sub = self.create_subscription(
            TFMessage,
            "/world/space_torque_test/dynamic_pose/info",
            self.pose_cb,
            10
        )

        self.torque_pub = self.create_publisher(
            Float32,
            "/reaction_wheel/net_torque",
            10
        )

        # ================= CONTROL PARAMS =================
        self.target_rel = math.radians(args.target)

        self.kp = args.kp
        self.kd = args.kd

        self.bias_pwm = args.bias
        self.max_delta_pwm = args.max_delta
        self.cmd_torque_max = args.cmd_torque_max

        self.tau_neutral = args.tau_neutral
        self.torque_scale = args.torque_scale
        self.torque_deadband = args.torque_deadband
        self.gazebo_torque_max = args.gazebo_torque_max
        self.torque_sign = args.torque_sign

        self.control_sign = args.control_sign

        self.initial_yaw = None
        self.yaw = None
        self.prev_yaw = None
        self.prev_t = None
        self.yaw_rate = 0.0

        self.latest_tau_raw = 0.0
        self.latest_pwm1 = 1000
        self.latest_pwm2 = 1000
        self.have_serial_torque = False

        self.started_time = None
        self.target_hold_start = None
        self.done = False

        self.last_sent_pwm1 = None
        self.last_sent_pwm2 = None
        self.last_pwm_send_time = 0.0

        self.last_print = time.time()

        self.get_logger().info("Hardware attitude control basladi.")
        self.get_logger().info(f"Target = {args.target:.1f} deg")
        self.get_logger().info(f"Serial = {args.port} @ {args.baud}")
        self.get_logger().info(f"PWM limit: {self.bias_pwm} - {self.bias_pwm + self.max_delta_pwm}")
        self.get_logger().info(f"tau_neutral = {self.tau_neutral:+.4f} Nm")
        self.get_logger().info("Pose bekleniyor. Pose gelmeden motor baslamaz.")

        self.timer = self.create_timer(args.period, self.step)

    def clamp(self, x, lo, hi):
        return max(lo, min(hi, x))

    def pose_cb(self, msg):
        # dynamic_pose/info bridge isimleri bos getirdigi icin
        # cubesat ismi aramak yerine z'si en yuksek transformu seciyoruz.
        # Senin ciktiya gore CubeSat transformu z = 0.105 civarinda.
        if len(msg.transforms) == 0:
            return

        selected_tf = None
        max_z = -1e9

        for t in msg.transforms:
            z = t.transform.translation.z
            if z > max_z:
                max_z = z
                selected_tf = t

        if selected_tf is None:
            return

        yaw_now = quat_to_yaw(selected_tf.transform.rotation)
        now = self.get_clock().now().nanoseconds * 1e-9

        if self.initial_yaw is None:
            self.initial_yaw = yaw_now
            self.yaw = yaw_now
            self.prev_yaw = yaw_now
            self.prev_t = now
            self.started_time = time.time()

            self.get_logger().info(
                f"Initial yaw alindi: {math.degrees(yaw_now):+.2f} deg | "
                f"selected_z={max_z:.4f}"
            )
            return

        dt = now - self.prev_t

        if dt > 1e-4:
            dyaw = wrap_pi(yaw_now - self.prev_yaw)
            self.yaw_rate = dyaw / dt

        self.yaw = yaw_now
        self.prev_yaw = yaw_now
        self.prev_t = now


    def publish_torque_safe(self, msg):
        # ESP32'nin raporladigi GERCEK PWM'e bakiyoruz.
        # Motorlar daha hold-off'ta 1000/1000 iken veya sadece 1080/1080 bias'tayken
        # load cell noise Gazebo'yu dondurmesin.
        p1 = getattr(self, "latest_pwm1", None)
        p2 = getattr(self, "latest_pwm2", None)

        motor_diff_active = False

        if p1 is not None and p2 is not None:
            try:
                p1i = int(p1)
                p2i = int(p2)

                # Gercek diferansiyel komut basladi mi?
                # Ornek: 1081/1080, 1084/1080, 1080/1083
                if max(p1i, p2i) >= 1081 and abs(p1i - p2i) >= 1:
                    motor_diff_active = True

            except Exception:
                motor_diff_active = False

        if not motor_diff_active:
            msg.data = 0.0

        self.torque_pub.publish(msg)


    def send_pwm(self, pwm1, pwm2):
        pwm1 = int(self.clamp(pwm1, self.bias_pwm, self.bias_pwm + self.max_delta_pwm))
        pwm2 = int(self.clamp(pwm2, self.bias_pwm, self.bias_pwm + self.max_delta_pwm))

        now = time.time()

        # ESP32 remote timeout'a dusmesin diye ayni PWM olsa bile
        # belirli araliklarla p komutunu tekrar gonderiyoruz.
        same_pwm = (pwm1 == self.last_sent_pwm1 and pwm2 == self.last_sent_pwm2)

        if same_pwm and (now - self.last_pwm_send_time) < 0.35:
            return

        cmd = f"p {pwm1} {pwm2}\n"
        self.ser.write(cmd.encode())

        self.last_sent_pwm1 = pwm1
        self.last_sent_pwm2 = pwm2
        self.last_pwm_send_time = now

    def send_stop(self):
        try:
            self.ser.write(b"s\n")
        except Exception:
            pass

        msg = Float32()
        msg.data = 0.0

        for _ in range(5):
            self.publish_torque_safe(msg)

    def read_serial_lines(self):
        try:
            while self.ser.in_waiting > 0:
                line = self.ser.readline().decode(errors="ignore").strip()

                if not line:
                    continue

                if line.startswith("["):
                    continue

                parts = line.split()

                if len(parts) != 5:
                    continue

                try:
                    f1 = float(parts[0])
                    f2 = float(parts[1])
                    tau_raw = float(parts[2])
                    pwm1 = int(float(parts[3]))
                    pwm2 = int(float(parts[4]))
                except ValueError:
                    continue

                self.latest_tau_raw = tau_raw
                self.latest_pwm1 = pwm1
                self.latest_pwm2 = pwm2
                self.have_serial_torque = True

        except Exception as e:
            self.get_logger().warn(f"Serial okuma hatasi: {e}")

    def publish_measured_torque_to_gazebo(self):
        if not self.have_serial_torque:
            tau_clean = 0.0
            tau_gazebo = 0.0

        elif self.latest_pwm1 <= 1005 and self.latest_pwm2 <= 1005:
            # Motor stop ise load cell kalinti offsetini Gazebo'ya sokma.
            tau_clean = 0.0
            tau_gazebo = 0.0

        else:
            # 1080-1080 neutral offset temizleme
            tau_clean = self.latest_tau_raw - self.tau_neutral

            if abs(tau_clean) < self.torque_deadband:
                tau_clean = 0.0

            tau_gazebo = tau_clean * self.torque_scale * self.torque_sign
            tau_gazebo = self.clamp(
                tau_gazebo,
                -self.gazebo_torque_max,
                self.gazebo_torque_max
            )

        msg = Float32()
        msg.data = float(tau_gazebo)
        self.publish_torque_safe(msg)

        return tau_clean, tau_gazebo

    def step(self):
        self.read_serial_lines()

        if self.done:
            self.publish_measured_torque_to_gazebo()
            return

        if self.initial_yaw is None or self.yaw is None:
            # Pose gelmeden motoru baslatma.
            self.publish_measured_torque_to_gazebo()
            return

        target_yaw = wrap_pi(self.initial_yaw + self.target_rel)
        err = wrap_pi(target_yaw - self.yaw)

        # PD attitude controller
        tau_cmd = self.kp * err - self.kd * self.yaw_rate
        tau_cmd *= self.control_sign
        tau_cmd = self.clamp(tau_cmd, -self.cmd_torque_max, self.cmd_torque_max)

        # tau_cmd -> delta PWM
        delta_ratio = abs(tau_cmd) / self.cmd_torque_max
        delta_pwm = int(round(delta_ratio * self.max_delta_pwm))
        delta_pwm = int(self.clamp(delta_pwm, 0, self.max_delta_pwm))

        # Guvenli PWM mantigi:
        # Pozitif komut: Motor1 bias+delta, Motor2 bias
        # Negatif komut: Motor1 bias, Motor2 bias+delta
        #
        # Boylece hicbir motor 1080 altina dusmez.
        if tau_cmd > 0.0:
            pwm1 = self.bias_pwm + delta_pwm
            pwm2 = self.bias_pwm
        elif tau_cmd < 0.0:
            pwm1 = self.bias_pwm
            pwm2 = self.bias_pwm + delta_pwm
        else:
            pwm1 = self.bias_pwm
            pwm2 = self.bias_pwm

        # Hedefe gelme kontrolu
        err_deg = abs(math.degrees(err))
        rate_deg = abs(math.degrees(self.yaw_rate))

        if err_deg < self.args.stop_error_deg and rate_deg < self.args.stop_rate_deg:
            if self.target_hold_start is None:
                self.target_hold_start = time.time()
            elif time.time() - self.target_hold_start > self.args.hold_time:
                self.get_logger().info("Hedefe gelindi. Motorlar stop.")
                self.send_stop()
                self.done = True
                return
        else:
            self.target_hold_start = None

        # Timeout guvenligi
        if self.started_time is not None:
            if time.time() - self.started_time > self.args.max_time:
                self.get_logger().warn("Max sure doldu. Motorlar stop.")
                self.send_stop()
                self.done = True
                return

        # ESP32'ye PWM komutu gonder
        self.send_pwm(pwm1, pwm2)

        # Load cell'den gelen gercek torku Gazebo'ya bas
        tau_clean, tau_gazebo = self.publish_measured_torque_to_gazebo()

        now = time.time()

        if now - self.last_print > 0.5:
            self.last_print = now
            self.get_logger().info(
                f"yaw={math.degrees(self.yaw):+.1f} deg | "
                f"target={math.degrees(target_yaw):+.1f} deg | "
                f"err={math.degrees(err):+.1f} deg | "
                f"rate={math.degrees(self.yaw_rate):+.1f} deg/s | "
                f"tau_cmd={tau_cmd:+.4f} | "
                f"PWM={pwm1},{pwm2} | "
                f"raw={self.latest_tau_raw:+.4f} | "
                f"clean={tau_clean:+.4f} | "
                f"gz={tau_gazebo:+.4f}"
            )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--target", type=float, default=45.0)
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)

    parser.add_argument("--bias", type=int, default=1080)
    parser.add_argument("--max-delta", type=int, default=5)

    parser.add_argument("--kp", type=float, default=0.08)
    parser.add_argument("--kd", type=float, default=0.12)
    parser.add_argument("--cmd-torque-max", type=float, default=0.08)

    parser.add_argument("--tau-neutral", type=float, default=-0.0045)
    parser.add_argument("--torque-scale", type=float, default=30.0)
    parser.add_argument("--torque-deadband", type=float, default=0.0005)
    parser.add_argument("--gazebo-torque-max", type=float, default=0.08)

    parser.add_argument("--control-sign", type=float, default=1.0)
    parser.add_argument("--torque-sign", type=float, default=1.0)

    parser.add_argument("--period", type=float, default=0.20)
    parser.add_argument("--max-time", type=float, default=20.0)

    parser.add_argument("--stop-error-deg", type=float, default=2.0)
    parser.add_argument("--stop-rate-deg", type=float, default=2.0)
    parser.add_argument("--hold-time", type=float, default=2.0)

    args = parser.parse_args()

    rclpy.init()
    node = HardwareAttitudeControl(args)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().warn("CTRL+C alindi. Motorlar stop.")
        node.send_stop()

    node.send_stop()
    node.ser.close()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
